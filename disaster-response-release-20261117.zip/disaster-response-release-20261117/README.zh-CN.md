# 灾害流量预测模型：代码整理包

当前版本：**输入6帧、预测6帧；STAEformer＋GRU骨架＋情境相关响应库＋共享预测层在线更新，无响应输出门控。**

完整英文入口文档：[README.md](README.md)。训练时骨架、情境编码器和响应分支联合优化；在线阶段只更新骨架末尾共享线性预测层的权重和偏置增量。最终预测为 `max(0, 骨架预测 × (1 + 响应修正))`。

这里“无门控”指没有最终响应输出门控。骨架内部STAEformer与GRU特征融合仍有自己的融合门。为了兼容旧权重和保持随机初始化顺序，模型中保留了一些不参与当前预测的门控张量和初始化兼容类。

## 直接跑通代码

在解压目录执行：

```bash
python -m pip install -r requirements.txt
python -m disaster_response.demo --output demo_data
python -m disaster_response.cli train --config demo_data/config.json --data demo_data/observations.npz --output runs/demo_train --device cpu
python -m disaster_response.cli evaluate --config demo_data/config.json --data demo_data/observations.npz --checkpoint runs/demo_train/demo/trials/full/model.pt --output runs/demo_eval --device cpu
python -m unittest discover -s tests -v
```

合成数据只用于确认代码能运行，成绩不代表真实数据效果。包内没有原始数据、训练权重、账号凭据、其他baseline仓库或几百组历史调参脚本。

## 真实数据训练和评测

Florida当前配置为 `configs/florida_o019.json`，在线参数window=12、lr=3e-4、anchor=0.1。

```bash
python -m disaster_response.cli train --config configs/florida_o019.json --raw-root raw_datas --output runs/florida_train --device cuda:0
python -m disaster_response.cli evaluate --config configs/florida_o019.json --raw-root raw_datas --checkpoint runs/florida_train/us/trials/full/model.pt --output runs/florida_eval --device cuda:0
```

日本inflow/outflow分别使用对应 `*_validation_selected.json`；两个 `*_original.json` 保存原无门控配置。日本验证选中配置只是当前已验证的实验快照，并不替你确定论文最终采用哪组。没有把后续按测试指标筛选的所有配置都塞进包内。

数据可以使用原来的目录结构，也可转成通用NPZ并通过 `--data` 传入；字段见 [数据说明](docs/DATA_FORMAT.md)。路径全部由命令行指定。

## 完整模型＋5个消融

```bash
python -m disaster_response.ablate --config configs/florida_o019.json --raw-root raw_datas --output runs/florida_ablations --device cuda:0
```

输出 `ablation_results_wide_cn.csv`，六行依次为完整模型、去响应分支、去地区自适应、去在线更新、响应换MLP、仅冻结骨架。每行都有五种测试范围的MAE和RMSE。该入口固定配方，直接保留全部成绩，不按消融是否变差来筛选结果。

训练保存每轮断点，重跑相同命令可恢复；改配置或划分时使用新的输出目录。同一目录只运行一个任务。单种子只报告原始指标，不能由一个种子计算标准差。

## 需要讲清楚的协议

- 原实验配置显式使用 `original` 划分，仍有相邻划分5小时目标重叠；为兼容旧成绩保留。
- 新的无目标重叠实验请在训练和评测命令都加 `--split purged`，并重新训练。合成示例默认使用该策略。
- 归一化、地区参考曲线、相关图、社会信号统计和天气阈值只用训练输入拟合。
- 在线更新只读取当前时刻已经到达的标签。输出6步中不同预测步的标签会逐步到达，不需要等6步全齐才开始利用已到达的部分。
- 社会信号采用1小时滞后。默认未来天气为最近已观测天气的持续假设，不能把未来实测天气当预测天气传入。
- 历史气象数据产品的实际发布时间、数据授权和收集时区仍需由数据使用者核实。
- 本项目已经多次查看测试集调参；提供的配方和成绩属于探索性实验，不能据此声称独立测试上的泛化证明。
- LLM只辅助前期整理文献和定性规律；当前训练、预测不调用LLM，函数形式与时间尺度由研究者指定，可训练参数由数据学习。

## 开源发布状态

已保留STAEformer来源说明。原项目代码的许可证需要作者选择；第三方STAEformer的再分发授权也需确认。**本包没有擅自将全部代码标成MIT/Apache许可证**，具体见 [LICENSE_STATUS.md](LICENSE_STATUS.md)。没有上传GitHub，也没有包含你本机的原始数据和权重。

兼容性验证见 [VALIDATION_REPORT.json](docs/VALIDATION_REPORT.json)：6份现有权重可严格加载，初始化一致；Florida全部344个测试窗口的冻结与在线预测与原工程逐值一致。
